package com.microservice.planes;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MicroservicePlanesApplication {

	public static void main(String[] args) {
		SpringApplication.run(MicroservicePlanesApplication.class, args);
	}

}
