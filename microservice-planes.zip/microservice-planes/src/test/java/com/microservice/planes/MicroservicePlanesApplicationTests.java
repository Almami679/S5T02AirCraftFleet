package com.microservice.planes;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MicroservicePlanesApplicationTests {

	@Test
	void contextLoads() {
	}

}
